#!/usr/bin/env python
# coding: utf-8

# In[10]:


import pandas as pd
import numpy as np


# In[11]:


train = pd.read_csv('mnist_train.csv')
test = pd.read_csv('mnist_test.csv')


# In[12]:


Y_train = train.iloc[:,0]
Y_train = pd.DataFrame(Y_train).to_numpy()
Y_train = Y_train.reshape(60000)
X_train = train.iloc[:,1:785]
X_train = pd.DataFrame(X_train).to_numpy()
Y_test = test.iloc[:,0]
Y_test = pd.DataFrame(Y_test).to_numpy()
Y_test = Y_test.reshape(10000)
X_test = test.iloc[:,1:785]
X_test = pd.DataFrame(X_test).to_numpy()


# In[13]:


X_train = X_train.reshape(60000,28,28)
X_test = X_test.reshape(10000,28,28)


# In[14]:


X_train = X_train/255
X_test = X_test/255


# In[15]:


import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

def show_number(indeks):
    """Show number using matplotlib, indeks should be in range 0 - 59999"""
    plt.imshow(X_train[indeks])
    plt.title("Digit: " + str(Y_train[indeks]))
    plt.show()
    
show_number(5)


# In[16]:


X_train = X_train.reshape(60000,784)
X_test = X_test.reshape(10000,784)


# In[9]:


def examine_model(model, X_train, Y_train, X_test, Y_test):
    model.fit(X_train,Y_train)
    accuracy = model.score(X_test, Y_test)
    return accuracy


# In[10]:


from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier


# In[11]:


accuracy = examine_model(LogisticRegression(max_iter=1000), X_train, Y_train, X_test, Y_test)
print("Logistic regression:")
print(accuracy)


# In[12]:


accuracy = examine_model(RandomForestClassifier(), X_train, Y_train, X_test, Y_test)
print("Random Forest Classifier:")
print(accuracy)


# In[13]:


accuracy = examine_model(KNeighborsClassifier(),X_train, Y_train, X_test, Y_test)
print("K-Neighbors Classifier:")
print(accuracy)


# In[14]:


accuracy = examine_model(LogisticRegression(max_iter=1500), X_train, Y_train, X_test, Y_test)
print("Logistic regression:")
print(accuracy)


# In[15]:


from sklearn import svm


# In[16]:


accuracy = examine_model(svm.SVC(kernel='linear'), X_train, Y_train, X_test, Y_test)
print("SVM regression:")
print(accuracy)


# In[20]:


from keras.layers import Input, Dense, Activation, ZeroPadding2D, BatchNormalization, Flatten, Conv2D
from keras.layers import AveragePooling2D, MaxPooling2D
from keras.models import Model
from keras.layers import Dropout


# In[21]:


def two_layers_sigmoid(input_shape):
    X_input = Input(input_shape)
    X = Dense(784, activation="sigmoid", name="first")(X_input)
    X = Dense(784, activation="sigmoid", name="second")(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = two_layers_sigmoid(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 30, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)

print(nn_predictions) #two layer sigmoid epoch 30
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[22]:


def two_layers_relu_20(input_shape):
    X_input = Input(input_shape)
    X = Dense(784, activation="relu", name="first")(X_input)
    X = Dense(784, activation="relu", name="second")(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = two_layers_relu_20(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 20, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)

print(nn_predictions) #two layer relu epoch 20
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[23]:


def two_layers_relu_diff(input_shape):
    X_input = Input(input_shape)
    X = Dense(256, activation="relu", name="first")(X_input)
    X = Dense(64, activation="relu", name="second")(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = two_layers_relu_diff(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 20, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 20 epoch diff neurons
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[24]:


def three_layers_relu_diff(input_shape):
    X_input = Input(input_shape)
    X = Dense(256, activation="relu", name="first")(X_input)
    X = Dense(256, activation="relu", name="second")(X)
    X = Dense(64, activation="relu", name="third")(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = three_layers_relu_diff(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 20, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 20 epoch diff neurons
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[25]:


from keras.layers import Dropout


# In[26]:


def three_layers_relu_diff_drop(input_shape):
    X_input = Input(input_shape)
    X = Dense(256, activation="relu", name="first")(X_input)
    X = Dropout(0.2)(X)
    X = Dense(256, activation="relu", name="second")(X)
    X = Dropout(0.2)(X)
    X = Dense(64, activation="relu", name="third")(X)
    X = Dropout(0.2)(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = three_layers_relu_diff_drop(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 20, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 20 epoch diff neurons and dropout
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[27]:


def two_layers_relu_drop(input_shape):
    X_input = Input(input_shape)
    X = Dense(784, activation="relu", name="first")(X_input)
    X = Dropout(0.2)(X)
    X = Dense(784, activation="relu", name="second")(X)
    X = Dropout(0.2)(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = two_layers_relu_drop(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 20, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 20 epoch same neurons dropout
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[ ]:


plt.savefig("squares.png")


# In[28]:


def three_layers_relu_diff_drop(input_shape):
    X_input = Input(input_shape)
    X = Dense(256, activation="relu", name="first")(X_input)
    X = Dropout(0.2)(X)
    X = Dense(256, activation="relu", name="second")(X)
    X = Dropout(0.2)(X)
    X = Dense(64, activation="relu", name="third")(X)
    X = Dropout(0.2)(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = three_layers_relu_diff_drop(X_train.shape[1:])
NN_model.compile(optimizer = "SGD", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 20, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 20 epoch diff neurons and dropout,opti sgd
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[29]:


def two_layers_relu_drop(input_shape):
    X_input = Input(input_shape)
    X = Dense(784, activation="relu", name="first")(X_input)
    X = Dropout(0.2)(X)
    X = Dense(784, activation="relu", name="second")(X)
    X = Dropout(0.2)(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = two_layers_relu_drop(X_train.shape[1:])
NN_model.compile(optimizer = "SGD", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 20, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 20 epoch same neurons dropout, opti SGD
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[30]:


def three_layers_relu(input_shape):
    X_input = Input(input_shape)
    X = Dense(784, activation="relu", name="first")(X_input)
    X = Dense(784, activation="relu", name="second")(X)
    X = Dense(784, activation="relu", name="third")(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = three_layers_relu(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 30, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 30 epoch 3 layer 784x3
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[32]:


def two_layers_relu(input_shape):
    X_input = Input(input_shape)
    X = Dense(784, activation="relu", name="first")(X_input)
    X = Dense(784, activation="relu", name="second")(X)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='Two_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = two_layers_relu(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 30, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 30 epoch 2 layer
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[33]:


def one_layers_relu(input_shape):
    
    X_input = Input(input_shape)
    X = Dense(784, activation="relu", name="first")(X_input)
    X = X = Dense(10, activation="softmax", name="last")(X)
    
    model = Model(inputs = X_input, outputs = X, name='one_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = one_layers_relu(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 30, batch_size = 32)
nn_predictions = NN_model.evaluate(x = X_test, y = Y_test)
print(nn_predictions) # relu 30 epoch one layer 784 hidden units
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[34]:


def zero_layers_relu(input_shape):
    X_input = Input(input_shape)
    X = Dense(10, activation="softmax", name="last")(X_input)
    
    model = Model(inputs = X_input, outputs = X, name='zero_hidden_layers')

    return model
print(X_train.shape[1:])
NN_model = zero_layers_relu(X_train.shape[1:])
NN_model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy", metrics = ["accuracy"])
history = NN_model.fit(x = X_train, y = Y_train,validation_data=(X_test, Y_test), epochs = 30, batch_size = 32)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()


# In[ ]:




